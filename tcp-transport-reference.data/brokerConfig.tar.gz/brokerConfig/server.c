#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>

main(int argc, char **argv)
{
	int port;
	char cport[10]; /* more then long enough for any legal port */

	if (argc != 2) {
		fprintf(stderr, "Must specify single argument\n");
		exit(1);
	}

	++argv;
	/* check to make sure port starts with a digit */
	if (! isdigit( (int)(**argv)) ) {
		fprintf(stderr, "Port must specified as a non-negative number\n");
		exit(1);
	}

	port = atoi(*argv);

	/* port numbers are between 0 and 65535 */
	if (port < 0 || port > 65535) {
		fprintf(stderr, "Port number out of range. Must be 0-65535.\n");
		exit(1);
	}

	sprintf(cport, "%d", port);

	/* call shell script with validated inputs */
	execl(SERVER, SERVER, cport, (char *)NULL);
}
