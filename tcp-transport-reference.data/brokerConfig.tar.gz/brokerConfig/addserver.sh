#!/bin/sh

# attempt some security hardening
IFS=" 	
"
PATH=/usr/bin:/usr/sbin:/bin:/sbin

# modify if iptables is not installed in /sbin
IPTABLES=/sbin/iptables

# on which server port are we going to set DSCP bits based on client values
PORT=$1

case `whoami` in
    root)
	;;
    *)
	echo "$0: Must be run with root privileges"
	exit 1
	;;
esac

# for incoming packets to server send to dscp_mark chain to mark connection
$IPTABLES -t mangle -A INPUT -p tcp --dport $PORT -j dscp_mark

# for outgoing packets from server send to dscp_mangle chain
$IPTABLES -t mangle -A OUTPUT -p tcp --sport $PORT -j dscp_mangle
